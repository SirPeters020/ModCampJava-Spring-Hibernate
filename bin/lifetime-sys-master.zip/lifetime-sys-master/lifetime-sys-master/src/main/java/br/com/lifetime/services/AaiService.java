package br.com.lifetime.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.lifetime.domain.Aai;
import br.com.lifetime.exceptions.ObjectNotFoundException;
import br.com.lifetime.repositories.AaiRepository;
import br.com.lifetime.services.exception.DataIntegrityException;

/**
 * 
 * Classe contendo todas as regras de negocio 
 *
 */
@Service
public class AaiService {

	@Autowired
	private AaiRepository repository;
	
	public Aai find(Integer id) {
		Optional<Aai> obj = repository.findById(id);
		if (obj == null) {
			throw new ObjectNotFoundException("Arquivo n�o encontrado! Codigo: " + id);
		}
		return obj.orElse(null);
	}
	
	public Aai insert(Aai obj) {
		obj.setId(null);
		return repository.save(obj); 
	}

	public Aai update(Aai obj) {
		find(obj.getId());
		return repository.save(obj);
	}
	
	public void delete (Integer id) {
		find(id);
		try {
			repository.deleteById(id);
		} 
		catch (DataIntegrityException e) {
			throw new DataIntegrityException("não foi possivel concluir a exclusão !");
		}
	}
	
	public List<Aai> finaAll(){
		return (List<Aai>) repository.findAll();
	}
	
}
