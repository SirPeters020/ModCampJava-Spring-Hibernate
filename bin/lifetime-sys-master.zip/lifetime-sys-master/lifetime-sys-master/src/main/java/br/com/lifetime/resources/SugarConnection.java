package br.com.lifetime.resources;

//import static view.sub.ReportDes.TODOS;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.lifetime.domain.Cliente;

//import model.Produto;

/**
 * Classe de conexão com o Sugar.
 */
@RestController
@RequestMapping(value = "/login")
public class SugarConnection {
    
    private static URL url, url2;
    private static final String urls = "https://lftm.sugarondemand.com/rest/v11";
    private static HttpURLConnection con, con2;
    public static String username = "";
    private static String password = "";
    public static String accessToken;
    private static String team_id;
    private static String user_id;
    public static boolean is_admin = false;
    public static boolean is_asset = false;
    public static boolean is_officer = false;
    private static Cliente cliente;
    public static int status, status2;

    /**
     * Construtor da classe.
     */
    public SugarConnection() {}

    /**
     * M�todo para validar login no Sugar.
     * @param usuario usuario
     * @param senha senha
     * @return boolean login realizado
     */
    @RequestMapping( method = RequestMethod.POST)
    public static Boolean SugarLogin (@RequestParam(value = "usuario") String usuario, @RequestParam(value = "senha") String senha) {
        String inputLine;
        //setting up connection url
        
        username = usuario;
        password = senha;
        //username = "samuel.conceicao";
        //password = "SC@lftm2019";

        try {
            url = new URL(urls+"/oauth2/token");
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(20000); 
            con.setReadTimeout(20000); 
        } catch (java.net.MalformedURLException error) {
            System.out.println("Error on URL");
        } catch (java.io.IOException error) {
            System.out.println("Error on connection setup");
        }
        //setting parameters
        Map<String,String> parameters = new HashMap<>();
        parameters.put("grant_type", "password");
        parameters.put("client_id", "sugar");
        parameters.put("username", username);
        parameters.put("password", password);
        parameters.put("platform", "alocapro");
        // set parameters to the connection
        try {
            con.setDoOutput(true);
            OutputStream os = con.getOutputStream(); // here
            DataOutputStream out = new DataOutputStream(os);
            out.writeBytes(ParameterStringBuilder.getParamsString(parameters)); 
            out.flush();
            out.close();
        } catch (java.net.ProtocolException error) {
            System.out.println("Error on Login");
            return false;
        } catch (java.io.IOException error) {
            System.out.println("Error on connection parameters");
            return false;
        }
         //executing and getting response
        try {
            status = con.getResponseCode(); 
            InputStream is = con.getInputStream(); 
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer content = new StringBuffer();
            while((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            try {
                JSONObject Response = new JSONObject(content.toString());
                accessToken = Response.getString("access_token");
                username = usuario;
                password = senha;
                
            } catch(org.json.JSONException error) {
                System.out.println("Error on Json Object");
            }
            in.close();
//            if (status == 200)  // bloco if/else comentado inicialmente
//                return true;
//            else
//                return false;
            
        } catch (java.io.IOException error) {
            System.out.println("Error on connection output");
            return false;
        }
        //Pegando id do time
        
        try {
            url = new URL(urls + "/Users?filter[0][user_name]="+username+"");
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(20000);
            con.setReadTimeout(20000);
            con.setRequestProperty("OAuth-Token", accessToken);
            status = con.getResponseCode();

            InputStream is = con.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer content = new StringBuffer();

            while((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }

            JSONObject Response = new JSONObject(content.toString());
            JSONArray Records = Response.getJSONArray("records");
            JSONObject one = Records.getJSONObject(0);
            in.close();
            cliente = new Cliente();
            if ("".equals(one.getString("id")) || one.getString("id") == null)
                return false;
            else {
                JSONArray team = one.getJSONArray("team_name");
                for(int i = 0; i < team.length(); i++){
                    JSONObject t = team.getJSONObject(i);
                    if(t.getString("id").equals("62e7bffc-99ab-11e9-8ff4-069e4f790264") || t.getString("name").equals("OFFICERS")){
                        is_officer = true;
                    }
                }
                is_admin = one.getBoolean("is_admin");
                user_id = one.getString("id");
                team_id = one.getString("default_team");
                
                if(team_id.equals("801fe6be-bd9b-11e7-93d5-06e5351e95d9")){
                    is_asset = true;
                }
            }
        } catch(org.json.JSONException error) {
            System.out.println("Error on Json Object Cliente");
        } catch (java.net.MalformedURLException error) {
            System.out.println("Error on URL");
        } catch (java.io.IOException error) {
            System.out.println("Error on connection setup");
        } 
        return true;
        }
    
    /**
     * Método para verificar se o login expirou.
     * @return boolean expirou
     */
    public static boolean isExpired () {
        try {
            url2 = new URL(urls+"/Contacts");
            con2 = (HttpURLConnection) url2.openConnection();
            con2.setRequestMethod("GET");
            con2.setConnectTimeout(20000);
            con2.setReadTimeout(20000);
            con2.setRequestProperty("OAuth-Token", accessToken);
            status2 = con2.getResponseCode();

            if (status2 != 200)
                return true;
        } catch (IOException | IllegalStateException e) {}
        return false;
    }
}
//    /**
//     * Método para verificar se é cliente no Sugar
//     * @param cliente cliente
//     * @return boolean é cliente
//     */
//    public static boolean isClient (Cliente cliente) {
//        String inputLine;
//        if(isExpired()) {return false;}
//        //setting up connection url
//        try {
//            url = new URL(urls + "/Contacts" +
//                    "?filter[0][lftm_numero_conta_c]="+cliente.getcodigoXp()+""); //alterado: :getCodigo
//            con = (HttpURLConnection) url.openConnection();
//            con.setRequestMethod("GET");
//            con.setConnectTimeout(20000);
//            con.setReadTimeout(20000);
//            con.setRequestProperty("OAuth-Token", accessToken);
//            status = con.getResponseCode();
//
//            InputStream is = con.getInputStream();
//            BufferedReader in = new BufferedReader(new InputStreamReader(is));
//            StringBuffer content = new StringBuffer();
//
//            while((inputLine = in.readLine()) != null) {
//                content.append(inputLine);
//            }
//
//            JSONObject Response = new JSONObject(content.toString());
//            JSONArray Records = Response.getJSONArray("records");
//            JSONObject one = Records.getJSONObject(0);
//            in.close();
//            if ("".equals(one.getString("id")) || one.getString("id") == null)
//                return false;
//            else {
//                //TODO atribuir cliente
//                cliente.setcodigoXp(one.getString("lftm_numero_conta_c")); //alterado: :getCodigo
//                cliente.setNmCliente(one.getString("name")); //alterado setNome
//                cliente.setId(one.getString("id"));
//                cliente.setEmail(one.getString("email1"));
//              
//                Object value = one.get("lftm_it_vida_app_c");
//                if(value instanceof Boolean){
//                    cliente.setVida(one.getBoolean("lftm_it_vida_app_c"));
//                }else{   cliente.setVida(false);   }
//                
//                
//                switch (one.getString("lftm_suitability_proprio_c")) {
//                    case "Ultraconservador":
//                        cliente.setPerfil("UC");
//                        break;
//                    case "Conservador":
//                        cliente.setPerfil("C");
//                        break;
//                    case "Moderado":
//                        cliente.setPerfil("M");
//                        break;
//                    case "ModeradoAgressivo":
//                        cliente.setPerfil("MA");
//                        break;
//                    case "Agressivo":
//                        cliente.setPerfil("A");
//                        break;
//                    default:
//                        cliente.setPerfil("");
//                }
//                    return true;
//            }
//        } catch(org.json.JSONException error) {
//            System.out.println("Error on Json Object Cliente");
//            System.out.println("error: " +error);
//        } catch (java.net.MalformedURLException error) {
//            System.out.println("Error on URL");
//        } catch (java.io.IOException error) {
//            System.out.println("Error on connection setup");
//        }
//        return false;
//    }
//    /**
//     * Método para criar tarefa no Sugar.
//     * @param compras compras
//     * @param vendas vendas
//     * @param c cliente
//     * @param comment comentário tarefa
//     * @param listaDesen lista desenquadrados
//     * @param listaDesEnq lista enquadrando
//     * @return boolean tarefa criada
//     */
//    public static boolean createTask (ArrayList<Produto> compras, ArrayList<Produto> vendas, Cliente c, String comment, ArrayList<String> listaDesen, ArrayList<String> listaDesEnq) {
//        Produto p;
//
//        System.out.println("Enviando Tarefa");
//        
//        if(isExpired()) {
//            JOptionPane.showMessageDialog(null, "Login Expirado");
//            return false;
//        }
//        
//        String order = "";
//        if(c.getCodigo().contains("N")){ order = "Cliente Novo: " + c.getNome() + "\n\n\n";}
//        order += comment;
//
//    // ------------------------ INICIALIZAÇÃO ARRAYS-------------------------------- //    
//        SimpleDateFormat data = new SimpleDateFormat("dd/MM/yyyy");
//        
//        ArrayList<Produto> comprasFixa = new ArrayList<>();
//        ArrayList<Produto> vendasFixa = new ArrayList<>();
//        ArrayList<Produto> comprasVar = new ArrayList<>();
//        ArrayList<Produto> vendasVar = new ArrayList<>();
//        ArrayList<Produto> comprasFundos = new ArrayList<>();
//        ArrayList<Produto> vendasFundos = new ArrayList<>();
//        ArrayList<Produto> comprasCOE = new ArrayList<>();
//        ArrayList<Produto> vendasCOE = new ArrayList<>();
//
//        // COMPRAS
//        for (int i = 0; i < compras.size(); i++) {
//            if((compras.get(i).getClassificacao_id() <10)  && !(compras.get(i).getAtivo().contains("FUNDO")) && !(compras.get(i).getAtivo().contains("PREVIDÊNCIA"))){
//                comprasFixa.add(compras.get(i));
//            }
//            else if((compras.get(i).getClassificacao_id()>=13 && compras.get(i).getClassificacao_id()<16) && !"COE".equals(compras.get(i).getNome()) 
//                    && !(compras.get(i).getAtivo().contains("FUNDO")) && !(compras.get(i).getAtivo().contains("PREVIDÊNCIA"))){
//                comprasVar.add(compras.get(i));
//            }
//            if(compras.get(i).getAtivo().contains("FUNDO") || compras.get(i).getAtivo().contains("PREVIDÊNCIA") 
//                    || compras.get(i).getClassificacao_id()>=10 && compras.get(i).getClassificacao_id() <=12)
//            {comprasFundos.add(compras.get(i));}
//        }
//        // VENDAS
//        for (int i = 0; i < vendas.size(); i++) {
//            if(vendas.get(i).getClassificacao_id()<10 && vendas.get(i).getClassificacao_id()!=0 && !(vendas.get(i).getAtivo().contains("Fundos")) && !(vendas.get(i).getAtivo().contains("Previdência"))){
//                vendasFixa.add(vendas.get(i));
//            }
//            else if((vendas.get(i).getClassificacao_id()>=13 && vendas.get(i).getClassificacao_id()<16) && !"COE".equals(vendas.get(i).getNome())
//                    && !(vendas.get(i).getAtivo().contains("Fundos")) && !(vendas.get(i).getAtivo().contains("Previdência"))) {
//                vendasVar.add(vendas.get(i));
//            }
//            if(vendas.get(i).getAtivo().contains("Fundos") || vendas.get(i).getAtivo().contains("Previdência") 
//                    || vendas.get(i).getClassificacao_id()>=10 && vendas.get(i).getClassificacao_id() <=12)
//            { vendasFundos.add(vendas.get(i));}
//            
//        }
//        for (int i = 0; i < compras.size(); i++) {
//            if("COE".equals(compras.get(i).getNome())){  comprasCOE.add(compras.get(i)); }
//        }
//        for (int i = 0; i < vendas.size(); i++) {
//            if("COE".equals(vendas.get(i).getNome())) {  vendasCOE.add(vendas.get(i));   }
//        }
//        // -------------------------------------------------------- //    
//        
//        order += "\n\nVender";
//        // RENDA VARIAVEL   vendasVar
//        if(!vendasVar.isEmpty()){
//            order += "\n\n - Renda Variável:";
//            for (int i = 0; i < vendasVar.size(); i++) {
//                p = vendasVar.get(i);
//                order += "\n| Nome : " + p.getNome();
//                order += " | Emissor : " + p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                if (p.getNet() == p.getMaxNet()) {  order += " | NET : Venda Total"; }
//                else {    order += " | NET : " + NumberFormat.getCurrencyInstance().format(p.getNet());   }
//                if (p.getDataVencimento() != null) {  order += " | Data Vencimento : " + data.format(p.getDataVencimento());}
//            }
//        }
//        // RENDA FIXA       
//        if(!vendasFixa.isEmpty()){
//            order += "\n\n - Renda Fixa:";
//            for(int i = 0; i < vendasFixa.size(); i++) {
//                p = vendasFixa.get(i);
//                order += "\n| Nome : "+p.getNome();
//                order += " | Emissor : "+p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                if(p.getNet() == p.getMaxNet()) {  order += " | NET : Venda Total";  }
//                else {   order += " | NET : "+NumberFormat.getCurrencyInstance().format(p.getNet());    }
//                if(p.getDataVencimento() != null){  order += " | Data Vencimento : "+data.format(p.getDataVencimento());   }
//            }
//        }
//        // FUNDOS           
//        if(!vendasFundos.isEmpty()){
//            order += "\n\n - Fundos:";
//            for(int i = 0; i < vendasFundos.size(); i++) {
//                p = vendasFundos.get(i);
//                order += "\n| Nome : "+p.getNome();
//                order += " | Emissor : "+p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                if(p.getNet() == p.getMaxNet()) { order += " | NET : Venda Total"; }
//                else {    order += " | NET : "+NumberFormat.getCurrencyInstance().format(p.getNet());  }
//                if(p.getDataVencimento() != null){  order += " | Data Vencimento : "+data.format(p.getDataVencimento());}
//            }
//        }
//        // COE              
//        if(!vendasCOE.isEmpty()){
//            order += "\n\n - COE:";
//            for(int i = 0; i < vendasCOE.size(); i++) {
//                p = vendasCOE.get(i);
//                order += "\n| Nome : "+p.getNome();
//                order += " | Emissor : "+p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                if(p.getNet() == p.getMaxNet()) {   order += " | NET : Venda Total"; }
//                else {    order += " | NET : "+NumberFormat.getCurrencyInstance().format(p.getNet());}
//                if(p.getDataVencimento() != null){  order += " | Data Vencimento : "+data.format(p.getDataVencimento());}
//            }
//        }
//        
//        order += "\n\nComprar";
//        // RENDA VARIAVEL   comprasVar
//        if(!comprasVar.isEmpty()){
//            order += "\n\n - Renda Variável";
//            for(int i = 0; i < comprasVar.size(); i++) {
//                p = comprasVar.get(i);
//                order += "\n| Nome : "+p.getAtivo();
//                order += " | Emissor : "+p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                order += " | NET : "+ NumberFormat.getCurrencyInstance().format(p.getNet());
//                order += " | Data Vencimento : "+data.format(p.getDataVencimento());
//            }
//        }
//        // RENDA FIXA       
//        if(!comprasFixa.isEmpty()){
//            order += "\n\n - Renda Fixa";
//            for(int i = 0; i < comprasFixa.size(); i++) {
//                p = comprasFixa.get(i);
//                order += "\n| Nome : "+p.getAtivo();
//                order += " | Emissor : "+p.getEmissor();
//                order += " | Indexador : "+p.getIndexadorNome();
//                order += " | NET : "+ NumberFormat.getCurrencyInstance().format(p.getNet());
//                order += " | Data Vencimento : "+data.format(p.getDataVencimento());
//            }
//        }
//        // FUNDOS           
//        if (!comprasFundos.isEmpty()) {
//            order += "\n\n - Fundo";
//            for (int i = 0; i < comprasFundos.size(); i++) {
//                p = comprasFundos.get(i);
//                order += "\n| Nome : " + p.getAtivo();
//                order += " | Emissor : " + p.getEmissor();
//                order += " | Indexador : " + p.getIndexadorNome();
//                order += " | NET : " + NumberFormat.getCurrencyInstance().format(p.getNet());
//                order += " | Data Vencimento : " + data.format(p.getDataVencimento());
//            }
//        }
//        // COE              
//        if (!comprasCOE.isEmpty()) {
//            order += "\n\n - COE";
//            for (int i = 0; i < comprasCOE.size(); i++) {
//                p = comprasCOE.get(i);
//                order += "\n| Nome : " + p.getAtivo();
//                order += " | Emissor : " + p.getEmissor();
//                order += " | Indexador : " + p.getIndexadorNome();
//                order += " | NET : " + NumberFormat.getCurrencyInstance().format(p.getNet());
//                order += " | Data Vencimento : " + data.format(p.getDataVencimento());
//            }
//        }
//        
//        // DESENQUADRADOS
//        if(!listaDesen.isEmpty() || !listaDesEnq.isEmpty()){
//            order+= "\n\n\n Categorias Desenquadradas: ";
//            if(!listaDesen.isEmpty()){
//                order+="\n\n - Desenquadrando (movimentação na direção ERRADA)";
//                for(String des: listaDesen){
//                    order +="\n" +des;
//                }
//            }
//            if(!listaDesEnq.isEmpty()){
//                order+="\n\n - Enquadrando (movimentação na direção certa)";
//                for(String enq: listaDesEnq){
//                    order +="\n" +enq;
//                }
//            }
//        }else{
//            order+= "\n\n\n Não há categorias desenquadradas";
//        }
//        //setting up connection url
//        try {
//            url = new URL(urls+"/Tasks");
//            con = (HttpURLConnection) url.openConnection();
//            con.setRequestMethod("POST");
//            con.setConnectTimeout(20000);
//            con.setReadTimeout(20000);
//            con.setRequestProperty("OAuth-Token", accessToken);
//        } catch (java.net.MalformedURLException error) {
//            System.out.println("Error on URL");
//        } catch (java.io.IOException error) {
//            System.out.println("Error on connection setup");
//        }
//
//        Date date = new Date();
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(date);
//        String year, month, day, hour, minute, second;
//
//        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
//
//
//        year = ""+cal.get(Calendar.YEAR);
//        if(cal.get(Calendar.MONTH) < 9) month = "0"+(cal.get(Calendar.MONTH)+1); else month = ""+(cal.get(Calendar.MONTH)+1);
//        if(cal.get(Calendar.DATE) < 10) day = "0"+cal.get(Calendar.DATE); else day = ""+cal.get(Calendar.DATE);
//        if(cal.get(Calendar.HOUR_OF_DAY) < 10) hour = "0"+cal.get(Calendar.HOUR_OF_DAY); else hour = ""+cal.get(Calendar.HOUR_OF_DAY);
//        if(cal.get(Calendar.MINUTE) < 10) minute = "0"+cal.get(Calendar.MINUTE); else minute = ""+cal.get(Calendar.MINUTE);
//        if(cal.get(Calendar.SECOND) < 10) second = "0"+cal.get(Calendar.SECOND); else second = ""+cal.get(Calendar.SECOND);
//
//        String date_start = year + "-" + month + "-" + day +
//                "T" + hour + ":" + minute + ":" + second + "-03:00";
//
//        if(cal.get(Calendar.HOUR_OF_DAY) >= 13) {cal.add(Calendar.DATE, 1);}
//
//        hour = "13";
//        minute = "00";
//        year = ""+cal.get(Calendar.YEAR);
//        if(cal.get(Calendar.MONTH) < 9) month = "0"+(cal.get(Calendar.MONTH)+1); else month = ""+(cal.get(Calendar.MONTH)+1);
//        if(cal.get(Calendar.DATE) < 10) day = "0"+cal.get(Calendar.DATE); else day = ""+cal.get(Calendar.DATE);
//
//        String date_due = year + "-" + month + "-" + day +
//                "T" + hour + ":" + minute + ":" + second +"-03:00";
//
//        //setting parameters
//        Map<String,String> parameters = new HashMap<>();
//        parameters.put("name", "Alocacao Clientes - AlocaPRO");
//        parameters.put("description", order);
//        parameters.put("team_id", team_id);
//        parameters.put("parent_type", "Contacts");
//        parameters.put("parent_id", c.getId());
//        parameters.put("lftm_tipo_tarefa_c", "RebalancearPrograma");
//        parameters.put("assigned_user_id", user_id);
//        parameters.put("date_start", date_start);
//        parameters.put("date_due", date_due);
//
//        for (String name: parameters.keySet()){
//            String key = name;
//            String value = parameters.get(name);
//            System.out.println("'"+ key + "' : '" + value + "'\n");
//        }
//
//        // set parameters to the connection
//        try {
//            con.setDoOutput(true);
//            OutputStream os = con.getOutputStream();
//            DataOutputStream out = new DataOutputStream(os);
//            out.writeBytes(ParameterStringBuilder.getParamsString(parameters));
//            out.flush();
//            out.close();
//            status = con.getResponseCode();
//            if (status == 200)
//                JOptionPane.showMessageDialog(null, "Dados enviados com sucesso");
//            else
//                JOptionPane.showMessageDialog(null, "Erro ao enviar dados: "+status);
//        } catch (java.net.ProtocolException error) {
//            System.out.println("Error on Login");
//            return false;
//        } catch (java.io.IOException error) {
//            System.out.println("Error on connection parameters");
//            return false;
//        }
//
//        return true;
//
//    }
//
//    /**
//     * Método para buscar cliente no Sugar.
//     * @param atribuir atribuido a quem
//     * @return ArrayList clientes
//     */
//    public static ArrayList<Cliente> getClientes(int atribuir){
//        ArrayList<Cliente> clientes = new ArrayList<>();
//        String inputLine;
//        int offset = 0;
//        if(isExpired()) {
//            return null;
//        }
//        
//        try {
//            do {
//                if(atribuir == TODOS){
//                    url = new URL(urls+"/Contacts?fields=assigned_user_name,assigned_user_id,lftm_numero_conta_c,lftm_suitability_proprio_c&offset="+offset);}
//                else{
//                    url = new URL(urls+"/Contacts?fields=assigned_user_name,assigned_user_id,lftm_numero_conta_c,lftm_suitability_proprio_c&offset="+offset+"&filter[0][assigned_user_id]="+user_id);}
//                con = (HttpURLConnection) url.openConnection();
//                con.setRequestMethod("GET");
//                con.setConnectTimeout(20000);
//                con.setReadTimeout(20000);
//                con.setRequestProperty("OAuth-Token", accessToken);
//                
//                status = con.getResponseCode();
//
//                InputStream is = con.getInputStream();
//                BufferedReader in = new BufferedReader(new InputStreamReader(is));
//                StringBuffer content = new StringBuffer();
//
//                while((inputLine = in.readLine()) != null) {
//                    content.append(inputLine);
//                }
//
//                JSONObject Response = new JSONObject(content.toString());
//                JSONArray Records = Response.getJSONArray("records");
//                for (int i = 0; i < Records.length(); i++) {
//                    Cliente c1 = new Cliente();
//                    JSONObject one = Records.getJSONObject(i);
//                    String perfil;
//                     switch (one.getString("lftm_suitability_proprio_c")) {
//                        case "Ultraconservador":
//                            perfil = "UC";
//                            break;
//                        case "Conservador":
//                            perfil = "C";
//                            break;
//                        case "Moderado":
//                            perfil = "M";
//                            break;
//                        case "ModeradoAgressivo":
//                            perfil = "MA";
//                            break;
//                        case "Agressivo":
//                            perfil = "A";
//                            break;
//                        default:
//                            perfil = "";
//                    }
//                    c1.setCodigo(one.getString("lftm_numero_conta_c"));
//                    c1.setAssessor(one.getString("assigned_user_name"));
//                    clientes.add(new Cliente(one.getString("lftm_numero_conta_c"), one.getString("assigned_user_name"), perfil));
//                }
//                offset = Response.getInt("next_offset");
//                in.close();
//            }while(offset != -1);
//            
//        } catch (MalformedURLException ex) {} catch (IOException | JSONException ex) {}
//        return clientes;
//    } 
//    
//}