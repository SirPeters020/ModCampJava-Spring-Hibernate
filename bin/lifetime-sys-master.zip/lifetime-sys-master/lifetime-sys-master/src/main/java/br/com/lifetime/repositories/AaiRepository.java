package br.com.lifetime.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.lifetime.domain.Aai;

/**
 * 
 * Interface para conex�o da tabela Aai com o banco de dados
 *
 */
@Repository
public interface AaiRepository extends JpaRepository<Aai, Integer>{

}
