package br.com.lifetime.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.lifetime.domain.SubCampanha;
import br.com.lifetime.exceptions.ObjectNotFoundException;
import br.com.lifetime.repositories.SubCampanhaRepository;
import br.com.lifetime.services.exception.DataIntegrityException;

/**
 * 
 * Classe contendo todas as regras de negocio 
 *
 */
@Service
public class SubCampanhaService {

	@Autowired
	private SubCampanhaRepository repository;
	
	public SubCampanha find(Integer id) {
		Optional<SubCampanha> obj = repository.findById(id);
		if (obj == null) {
			throw new ObjectNotFoundException("Arquivo não encontrado! Codigo: " + id);
		}
		return obj.orElse(null);
	}
	
	
	public SubCampanha insert(SubCampanha obj) {
		obj.setId(null);
		return repository.save(obj);
	}
	
	
	public SubCampanha update (SubCampanha obj) {
		find(obj.getId());
		return repository.save(obj);
	}
	
	public void delete(Integer id) {
		find(id);
		try {
			repository.deleteById(id);
		}
		catch (DataIntegrityException e) {
			throw new DataIntegrityException("não foi possivel concluir a exclusão !");
		}
	}
	
	public List<SubCampanha> finaAll(){
		return (List<SubCampanha>) repository.findAll();
	}
	
}
