package br.com.lifetime.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Service;

import br.com.lifetime.DTO.TabelaMesaDTO;
import br.com.lifetime.repositories.ControleCampanhaRepositoryCustom;

/**
 * 
 * @author pedro.silva Classe de implementação das consultas personalizadas
 *         através da classe ControleCampanhaRepositoryCustom
 *
 */
@Service
public class ControleCampanhaRepositoryImpl implements ControleCampanhaRepositoryCustom {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("teste");
	EntityManager em = emf.createEntityManager();

	@Override
	public List<TabelaMesaDTO> consultaTable() {
		em.getTransaction().begin();
		String jpql = "SELECT new br.com.lifetime.DTO.DataTableDTO(cc.elegivel, cc.fomento, "
				+ "cc.fomentoRealizado, cc.operacaoEnviada, cc.permissaoRecebida, "
				+ "cc.ordemExecutada, cc.qtdeValor, cl.id, cl.nmCliente, "
				+ "cl.perfilXp, a.nmAai, e.nmEquipe) "
				+ "FROM ControleCampanha cc "
				+ "INNER JOIN cc.cliente cl "
				+ "INNER JOIN cl.aai a "
				+ "INNER JOIN a.equipe e";
		Query query = em.createQuery(jpql);
		List<TabelaMesaDTO> result = query.getResultList();
		em.getTransaction().commit();
//		em.close();
		return result;
	}

}
