package br.com.lifetime.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.lifetime.DTO.TabelaMesaDTO;

/**
 * 
 * @author pedro.silva
 *  Classe de implementação das consultas personalizadas
 *  através da classe ControleCampanhaRepositoryCustom
 *
 */


@Repository
public class ControleCampanhaRepositoryImpl implements ControleCampanhaRepositoryCustom {

	@PersistenceContext
	EntityManager em;
	
	@Override
	@Transactional
	public List<TabelaMesaDTO> consultaTable(){
		String jpql = "SELECT new br.com.lifetime.DTO.TabelaMesaDTO(cc.elegivel, cc.fomento, "
				+ "cc.fomentoRealizado, cc.operacaoEnviada, cc.permissaoRecebida, "
				+ "cc.ordemExecutada, cc.qtdeValor, cl.id, cl.nmCliente, "
				+ "cl.perfilXp, a.nmAai, e.nmEquipe) "
				+ "FROM ControleCampanha cc "
				+ "INNER JOIN cc.cliente cl "
				+ "INNER JOIN cl.aai a "
				+ "INNER JOIN a.equipe e";
		Query query = em.createQuery(jpql);
		List<TabelaMesaDTO> result = query.getResultList();
//		em.close();
		return result;
	}

}
