package br.com.lifetime.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.lifetime.domain.HistoricoContCamp;

public interface HistoricoContCampRepository extends JpaRepository<HistoricoContCamp, Integer>{

}
