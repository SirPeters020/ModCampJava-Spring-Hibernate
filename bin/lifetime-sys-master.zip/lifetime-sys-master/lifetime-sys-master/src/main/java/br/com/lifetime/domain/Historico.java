package br.com.lifetime.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 * 
 * @author pedro.silva
 * Tabela para armazenar registros atualizados, antes de sua atualiza��o
 *
 */
@Entity
public class Historico implements Serializable{
	private static final long serialVersionUID = 1L;
	

	@ManyToOne(cascade = CascadeType.ALL)
	private ControleCampanha controleCampanha;
	private boolean elegivel;
	private boolean fomentoRealizado;
	private double qtdeValor;
	@Id
	private Integer id;
	
	public Historico () {
		
	}
	public Historico(Integer id, boolean elegivel, boolean fomentoRealizado, double qtdeValor) {
		super();
		this.id = id;
		this.elegivel = elegivel;
		this.fomentoRealizado = fomentoRealizado;
		this.qtdeValor = qtdeValor;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public boolean isElegivel() {
		return elegivel;
	}
	public void setElegivel(boolean elegivel) {
		this.elegivel = elegivel;
	}
	public boolean isFomentoRealizado() {
		return fomentoRealizado;
	}
	public void setFomentoRealizado(boolean fomentoRealizado) {
		this.fomentoRealizado = fomentoRealizado;
	}
	public double getQtdeValor() {
		return qtdeValor;
	}
	public void setQtdeValor(double qtdeValor) {
		this.qtdeValor = qtdeValor;
	}
	public ControleCampanha getControleCampanha() {
		return controleCampanha;
	}
	public void setControleCampanha(ControleCampanha controleCampanha) {
		this.controleCampanha = controleCampanha;
	}
			
}
