package br.com.lifetime.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * 
<<<<<<< HEAD
 * Classe contendo as configuracao de seguranca web
=======
 * Classe contendo as configural��es de seguran�a web
>>>>>>> 0f7f25a823458f269c3436ab3810b99b0f09d11c
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private Environment env;

	
	// Array com endpoint liberado sem passare pelo login
	private static final String[] PUBLIC_MATCHERS = {
			"/h2-console/**",
			"/aai/**",
			"/subcampanha/**",
			"/cliente/**",
			"/controlecampanha/**",
			"/equipe/**",
			"/estrategia/**",
			"/campanha/**",
			"/login/**",
			"/DataTableDTO/**",
			"/cadastrocampanha/**",
			"/cadastroestrategia/**",
			"/DataTableDTO/**"
	};
	
	// Array com endpoint liberado sem passar pelo login, porem apenas com o GET liberado
	private static final String[] PUBLIC_MATCHERS_GET = {  
			"/h2-console/**",
			"/aai/**",
			"/subcampanha/**",
			"/cliente/**",
			"/controlecampanha/**",
			"/equipe/**",
			"/estrategia/**",
			"/campanha/**"
	};
	
	/**
	 * Metodo para liberar endpoints e definindo pagina de login
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		if (Arrays.asList(env.getActiveProfiles()).contains("test")) {
			http.headers().frameOptions().disable();
		}
		http.cors().and().csrf().disable();
		http.
			authorizeRequests()
				.antMatchers(HttpMethod.GET, PUBLIC_MATCHERS_GET)
					.permitAll()
				.antMatchers(PUBLIC_MATCHERS)
			 		.permitAll()					
				.antMatchers("/tela-datatable")		//comentar/remover para login
					.permitAll()					//idem
					.antMatchers("/cadastrocampanha")		//comentar/remover para login
					.permitAll()
					.antMatchers("/cadastroestrategia")		//comentar/remover para login
					.permitAll()
					.antMatchers("/editcontrolecampanha")		//comentar/remover para login
					.permitAll()
					.anyRequest().authenticated()
				.and()
				.formLogin()
					.loginPage("/login")
					.failureUrl("/login")
					.defaultSuccessUrl("/tela-datatable")
					.loginProcessingUrl("/tela-datatable") //idem
					.permitAll();
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
	}
	
	/**
	 * Methodo para liberar acesso a pastas de config
	 */
	 @Override
	    public void configure(WebSecurity web) throws Exception {
	        web
	            .ignoring()
	            .antMatchers("/resources/**", "/static/**","/webjars/**", "/css/**", "/js/**", "/img/**");
	    }
	
	/**
	 * 
	 * Metodo para permitir acesso aos endpoins por multiplas fontes, com as config basicas
<<<<<<< HEAD
	 * permitindo requisicoes de multiplas fontes
=======
	 * permitindo requisi��es de multiplas fontes
>>>>>>> 0f7f25a823458f269c3436ab3810b99b0f09d11c
	 */
	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", new CorsConfiguration().applyPermitDefaultValues());
		return source;
	}
	
}
