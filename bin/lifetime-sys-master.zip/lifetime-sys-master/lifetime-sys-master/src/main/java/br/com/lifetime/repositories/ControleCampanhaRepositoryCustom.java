package br.com.lifetime.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.lifetime.DTO.TabelaMesaDTO;

/**
 * 
 * @author pedro.silva
<<<<<<< HEAD
 * Classe para metodos para consulta personalizada no BD
 *
 */

@Repository
public interface ControleCampanhaRepositoryCustom  {
	
	List<TabelaMesaDTO> consultaTable();

}