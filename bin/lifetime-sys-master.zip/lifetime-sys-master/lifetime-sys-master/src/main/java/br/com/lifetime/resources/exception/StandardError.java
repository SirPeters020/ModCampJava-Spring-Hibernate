package br.com.lifetime.resources.exception;

import java.io.Serializable;

/**
 * 
 * Classe auxiliar para formata��o de Exceptions em geral
 *
 */
public class StandardError implements Serializable{
	private static final long serialVersionUID = 1L;
	
	
	private Integer status;
	private String msg;
	private Long timeStramp;
	
	
	public StandardError(Integer status, String msg, Long timeStramp) {
		super();
		this.status = status;
		this.msg = msg;
		this.timeStramp = timeStramp;
	}


	public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


	public Long getTimeStramp() {
		return timeStramp;
	}


	public void setTimeStramp(Long timeStramp) {
		this.timeStramp = timeStramp;
	}
	
	
	
	
	
}
