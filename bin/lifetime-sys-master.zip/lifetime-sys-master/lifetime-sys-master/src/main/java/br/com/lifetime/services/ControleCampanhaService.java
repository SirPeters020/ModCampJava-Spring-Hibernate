package br.com.lifetime.services;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.lifetime.domain.ControleCampanha;
import br.com.lifetime.repositories.ControleCampanhaRepository;
import br.com.lifetime.services.exception.DataIntegrityException;

/**
 * 
 * Classe contendo todas as regras de negocio 
 *
 */
@Service
public class ControleCampanhaService {

	@Autowired
	private ControleCampanhaRepository repository;

	public ControleCampanha find(Integer id) {
		Optional<ControleCampanha> obj = repository.findById(id);
		if (obj == null) {
			throw new br.com.lifetime.exceptions.ObjectNotFoundException("Arquivo não encontrado! Codigo: " + id);
		}
		return obj.orElse(null);
	}

	public ControleCampanha insert(ControleCampanha obj) {
		obj.setId(null);
		return repository.save(obj);
	}

	public ControleCampanha update(ControleCampanha obj) {
		find(obj.getId());
		return repository.save(obj);
	}
	
	public void delete (Integer id) {
		find(id);
		try {
			repository.deleteById(id);
		}
		catch (DataIntegrityException e ) {
			throw new DataIntegrityException("não foi possivel excluir !");
		}
	}
	
	public List<ControleCampanha> finaAll(){
		return (List<ControleCampanha>) repository.findAll();
	}
	
}
