package br.com.lifetime.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.lifetime.domain.Historico;

public interface HistoricoRepository extends JpaRepository<Historico, Integer>{

}
